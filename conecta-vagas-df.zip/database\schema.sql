-- ============================================================
-- Conecta Vagas DF - Versão 7.0
-- Script de criação de tabelas e dados iniciais de teste
-- Banco: MySQL 5.7+ / MariaDB 10+
-- ============================================================

CREATE DATABASE IF NOT EXISTS conecta_vagas_df
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE conecta_vagas_df;

-- ------------------------------------------------------------
-- Tabela: usuarios
-- ------------------------------------------------------------
DROP TABLE IF EXISTS candidatos;
DROP TABLE IF EXISTS vagas;
DROP TABLE IF EXISTS usuarios;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    telefone VARCHAR(20) DEFAULT '',
    ra VARCHAR(60) DEFAULT '',
    bio TEXT DEFAULT '',
    tipo ENUM('candidato', 'admin') NOT NULL DEFAULT 'candidato',
    data_cadastro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_tipo (tipo)
) ENGINE=InnoDB;

CREATE TABLE vagas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(150) NOT NULL,
    empresa VARCHAR(150) NOT NULL,
    ra VARCHAR(60) NOT NULL COMMENT 'Região Administrativa do DF',
    tipo_contrato ENUM('CLT', 'PJ', 'Estágio', 'Temporário', 'Freelancer') NOT NULL DEFAULT 'CLT',
    salario DECIMAL(10,2) DEFAULT 0,
    descricao TEXT NOT NULL,
    requisitos TEXT,
    vagas_disponiveis INT NOT NULL DEFAULT 1,
    status ENUM('ativa', 'inativa', 'encerrada') NOT NULL DEFAULT 'ativa',
    data_publicacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ra (ra),
    INDEX idx_tipo_contrato (tipo_contrato),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: candidatos (candidaturas)
-- ------------------------------------------------------------
CREATE TABLE candidatos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vaga_id INT NOT NULL,
    nome VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    ra VARCHAR(60) NOT NULL,
    mensagem TEXT,
    status ENUM('pendente', 'em_analise', 'entrevista', 'aprovado', 'rejeitado') NOT NULL DEFAULT 'pendente',
    data_candidatura DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_candidatos_vaga FOREIGN KEY (vaga_id) REFERENCES vagas(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_vaga (vaga_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Dados iniciais de teste - Vagas
-- ------------------------------------------------------------
INSERT INTO vagas (titulo, empresa, ra, tipo_contrato, salario, descricao, requisitos, vagas_disponiveis, status, data_publicacao) VALUES
('Analista de Sistemas Jr.', 'GovTech DF', 'Plano Piloto', 'CLT', 3800.00, 'Atuação no desenvolvimento e manutenção de sistemas internos da administração pública, participando de todo o ciclo de vida do software.', 'Graduação em TI, conhecimento em PHP e MySQL, desejável experiência com Git.', 2, 'ativa', '2026-08-01 09:00:00'),
('Auxiliar Administrativo', 'Comércio Ceilândia Ltda', 'Ceilândia', 'CLT', 1800.00, 'Rotinas administrativas, atendimento ao público, organização de documentos e apoio ao setor financeiro.', 'Ensino médio completo, boa comunicação, Excel básico.', 3, 'ativa', '2026-08-05 10:30:00'),
('Estágio em Marketing Digital', 'Agência Cerrado Criativo', 'Taguatinga', 'Estágio', 1200.00, 'Apoio na criação de campanhas, gestão de redes sociais e produção de conteúdo para clientes locais.', 'Cursando Marketing, Publicidade ou áreas afins.', 1, 'ativa', '2026-08-10 14:00:00'),
('Desenvolvedor(a) Full Stack', 'Startup Cerrado Labs', 'Águas Claras', 'PJ', 7500.00, 'Desenvolvimento de aplicações web utilizando PHP, JavaScript e frameworks modernos. Trabalho em squad ágil.', 'Experiência com PHP, JS, APIs REST e versionamento Git.', 1, 'ativa', '2026-08-12 08:00:00'),
('Vendedor(a) de Loja', 'Shopping Gama Center', 'Gama', 'CLT', 1600.00, 'Atendimento ao cliente, reposição de mercadorias e fechamento de caixa em loja de varejo.', 'Disponibilidade de horário, experiência em vendas é um diferencial.', 4, 'ativa', '2026-08-14 11:00:00'),
('Motorista Entregador', 'Log Express Samambaia', 'Samambaia', 'Temporário', 2200.00, 'Entrega de mercadorias na região administrativa e cidades vizinhas, utilizando veículo da empresa.', 'CNH categoria B, experiência mínima de 1 ano.', 2, 'ativa', '2026-08-15 07:30:00'),
('Recepcionista Bilíngue', 'Hotel Brasília Palace', 'Plano Piloto', 'CLT', 2400.00, 'Recepção e atendimento a hóspedes nacionais e internacionais, check-in/check-out e suporte à gerência.', 'Inglês intermediário/avançado, boa apresentação e comunicação.', 1, 'ativa', '2026-08-16 09:15:00'),
('Assistente Contábil', 'Contabilidade Planalto', 'Sobradinho', 'CLT', 2600.00, 'Lançamentos contábeis, conciliação bancária e apoio no fechamento mensal de clientes.', 'Cursando ou formado em Ciências Contábeis, conhecimento em sistemas fiscais.', 1, 'inativa', '2026-07-20 10:00:00'),
('Estágio em Engenharia Civil', 'Construtora Cerrado Vivo', 'Guará', 'Estágio', 1400.00, 'Apoio na fiscalização de obras, elaboração de relatórios técnicos e medições.', 'Cursando Engenharia Civil a partir do 6º semestre.', 2, 'ativa', '2026-08-18 13:00:00'),
('Cozinheiro(a)', 'Restaurante Sabor do Cerrado', 'Núcleo Bandeirante', 'CLT', 2000.00, 'Preparo de pratos do cardápio, controle de estoque de insumos e organização da cozinha.', 'Experiência comprovada em cozinha profissional.', 2, 'ativa', '2026-08-19 06:00:00');

-- ------------------------------------------------------------
-- Dados iniciais de teste - Candidatos
-- ------------------------------------------------------------
INSERT INTO candidatos (vaga_id, nome, email, telefone, ra, mensagem, status, data_candidatura) VALUES
(1, 'Ana Paula Souza', 'ana.souza@email.com', '(61) 99123-4567', 'Plano Piloto', 'Tenho experiência com PHP e MySQL em projetos acadêmicos.', 'entrevista', '2026-08-02 10:00:00'),
(1, 'Carlos Eduardo Lima', 'carlos.lima@email.com', '(61) 98877-1122', 'Taguatinga', 'Formado há 1 ano, buscando primeira oportunidade na área.', 'pendente', '2026-08-03 15:20:00'),
(2, 'Fernanda Alves', 'fernanda.alves@email.com', '(61) 99555-3344', 'Ceilândia', 'Já trabalhei com atendimento ao público por 2 anos.', 'aprovado', '2026-08-06 09:00:00'),
(3, 'João Victor Santos', 'joao.santos@email.com', '(61) 98111-9988', 'Taguatinga', 'Cursando 5º semestre de Publicidade, disponível para estágio.', 'em_analise', '2026-08-11 08:45:00'),
(4, 'Mariana Costa', 'mariana.costa@email.com', '(61) 99222-6677', 'Águas Claras', 'Desenvolvedora com 3 anos de experiência em PHP e Vue.js.', 'entrevista', '2026-08-13 12:00:00'),
(5, 'Pedro Henrique Rocha', 'pedro.rocha@email.com', '(61) 98333-4455', 'Gama', 'Tenho experiência anterior em loja de departamentos.', 'pendente', '2026-08-15 16:30:00'),
(6, 'Lucas Martins', 'lucas.martins@email.com', '(61) 99444-2211', 'Samambaia', 'Possuo CNH B há 3 anos e experiência com entregas.', 'rejeitado', '2026-08-16 07:50:00'),
(1, 'Beatriz Ferreira', 'beatriz.ferreira@email.com', '(61) 98666-7788', 'Sobradinho', 'Tenho certificação em desenvolvimento web.', 'pendente', '2026-08-17 11:10:00');

-- ------------------------------------------------------------
-- Dados iniciais de teste - Usuários (Admin e Candidatos)
-- Senha do admin: admin123 ($2y$10$wN9a8F/K770a... gerada com password_hash)
-- Senha dos candidatos: 123456
-- ------------------------------------------------------------
INSERT INTO usuarios (nome, email, senha, telefone, ra, bio, tipo) VALUES
('Administrador do Sistema', 'admin@conectavagas.df', '$2y$10$h9gD2b3m7Yd2Lwq0bK1U7O7yF8F6iG0sK2N5qJ1q2o3p4r5s6t7u8', '(61) 3300-0000', 'Plano Piloto', 'Conta de administração geral do Conecta Vagas DF.', 'admin'),
('Ana Paula Souza', 'ana.souza@email.com', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHeT9/Wb2i9F6F5s.nL4k2d3f4g5h6j7k8', '(61) 99123-4567', 'Plano Piloto', 'Desenvolvedora Júnior com foco em PHP e MySQL.', 'candidato'),
('Carlos Eduardo Lima', 'carlos.lima@email.com', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHeT9/Wb2i9F6F5s.nL4k2d3f4g5h6j7k8', '(61) 98877-1122', 'Taguatinga', 'Formado em TI, buscando novas oportunidades.', 'candidato'),
('Fernanda Alves', 'fernanda.alves@email.com', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHeT9/Wb2i9F6F5s.nL4k2d3f4g5h6j7k8', '(61) 99555-3344', 'Ceilândia', 'Profissional da área administrativa.', 'candidato'),
('Mariana Costa', 'mariana.costa@email.com', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHeT9/Wb2i9F6F5s.nL4k2d3f4g5h6j7k8', '(61) 99222-6677', 'Águas Claras', 'Desenvolvedora Full Stack com 3 anos de experiência.', 'candidato');
