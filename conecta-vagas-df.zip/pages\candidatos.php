<?php
requireAdmin();

// ------------------------------------------------------------
// Atualizar status do candidato (POST)
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'status_candidato') {
    if (validateCSRFToken($_POST['csrf_token'] ?? '')) {
        updateCandidatoStatus((int) $_POST['candidato_id'], sanitizeInput($_POST['status']));
        setFlashMessage('success', 'Status do candidato atualizado.');
    } else {
        setFlashMessage('danger', 'Token de segurança inválido.');
    }
    redirect(BASE_URL . '?page=candidatos');
}

// ------------------------------------------------------------
// Excluir candidato (POST)
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'excluir_candidato') {
    if (validateCSRFToken($_POST['csrf_token'] ?? '')) {
        deleteCandidato((int) $_POST['candidato_id']);
        setFlashMessage('success', 'Candidato removido com sucesso.');
    }
    redirect(BASE_URL . '?page=candidatos');
}

// ------------------------------------------------------------
// Filtros
// ------------------------------------------------------------
$filtroStatus = sanitizeInput($_GET['status'] ?? '');
$filtroBusca  = sanitizeInput($_GET['busca'] ?? '');

$candidatos = getAllCandidatos([
    'status' => $filtroStatus,
    'busca'  => $filtroBusca,
]);

$statusOpcoes = getStatusCandidaturaOpcoes();
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
    <h1 class="h3 fw-bold mb-0"><i class="bi bi-people"></i> Gestão de Candidatos</h1>
    <span class="badge bg-primary fs-6"><?= count($candidatos) ?> candidato(s)</span>
</div>

<!-- Filtros -->
<form method="GET" action="<?= e(BASE_URL) ?>" class="card border-0 shadow-sm p-3 mb-4">
    <input type="hidden" name="page" value="candidatos">
    <div class="row g-2">
        <div class="col-md-4">
            <label class="form-label small fw-semibold">Status</label>
            <select name="status" class="form-select">
                <option value="">Todos os status</option>
                <?php foreach ($statusOpcoes as $key => $info): ?>
                    <option value="<?= e($key) ?>" <?= $filtroStatus === $key ? 'selected' : '' ?>><?= e($info['label']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-6">
            <label class="form-label small fw-semibold">Buscar por nome ou e-mail</label>
            <input type="text" name="busca" class="form-control" value="<?= e($filtroBusca) ?>">
        </div>
        <div class="col-md-2 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100"><i class="bi bi-funnel"></i> Filtrar</button>
        </div>
    </div>
</form>

<?php if (empty($candidatos)): ?>
    <div class="alert alert-secondary">Nenhum candidato encontrado.</div>
<?php else: ?>
    <div class="card border-0 shadow-sm">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Candidato</th>
                        <th>Vaga</th>
                        <th>Contato</th>
                        <th>RA</th>
                        <th>Data</th>
                        <th>Status</th>
                        <th class="text-end">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($candidatos as $c): ?>
                        <tr>
                            <td class="fw-semibold"><?= e($c['nome']) ?></td>
                            <td>
                                <div><?= e($c['vaga_titulo']) ?></div>
                                <div class="text-muted small"><?= e($c['vaga_empresa']) ?></div>
                            </td>
                            <td>
                                <div class="small"><i class="bi bi-envelope"></i> <?= e($c['email']) ?></div>
                                <div class="small"><i class="bi bi-telephone"></i> <?= e($c['telefone']) ?></div>
                            </td>
                            <td class="small"><?= e($c['ra']) ?></td>
                            <td class="small"><?= formatDate($c['data_candidatura']) ?></td>
                            <td style="min-width: 160px;">
                                <form method="POST" action="<?= e(BASE_URL) ?>?page=candidatos" class="d-flex gap-1 cvdf-status-form">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="acao" value="status_candidato">
                                    <input type="hidden" name="candidato_id" value="<?= (int) $c['id'] ?>">
                                    <select name="status" class="form-select form-select-sm cvdf-status-select bg-<?= e($statusOpcoes[$c['status']]['class'] ?? 'secondary') ?> text-white" onchange="this.form.submit()">
                                        <?php foreach ($statusOpcoes as $key => $info): ?>
                                            <option value="<?= e($key) ?>" <?= $c['status'] === $key ? 'selected' : '' ?>><?= e($info['label']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </form>
                            </td>
                            <td class="text-end">
                                <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#modalExcluirCand<?= (int) $c['id'] ?>">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </td>
                        </tr>

                        <div class="modal fade" id="modalExcluirCand<?= (int) $c['id'] ?>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" action="<?= e(BASE_URL) ?>?page=candidatos">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="acao" value="excluir_candidato">
                                        <input type="hidden" name="candidato_id" value="<?= (int) $c['id'] ?>">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Remover Candidato</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            Deseja remover a candidatura de <strong><?= e($c['nome']) ?></strong> para a vaga <strong><?= e($c['vaga_titulo']) ?></strong>?
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                            <button type="submit" class="btn btn-danger">Remover</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
