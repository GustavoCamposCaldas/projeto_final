/**
 * Conecta Vagas DF - Script de Interface
 * Versão 7.0
 *
 * Validações client-side (complementares à validação server-side em PHP),
 * auto-dismiss de alertas e pequenas melhorias de UX.
 * IMPORTANTE: toda a validação e sanitização real acontece no backend
 * (functions.php). Este script é apenas uma camada de conveniência.
 */

(function () {
    'use strict';

    // ------------------------------------------------------------
    // Validação Bootstrap nos formulários com classe .needs-validation
    // ------------------------------------------------------------
    function initFormValidation() {
        var forms = document.querySelectorAll('.needs-validation');
        forms.forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    }

    // ------------------------------------------------------------
    // Auto-dismiss de alertas flash após alguns segundos
    // ------------------------------------------------------------
    function initAutoDismissAlerts() {
        var alerts = document.querySelectorAll('.alert-dismissible');
        alerts.forEach(function (alertEl) {
            setTimeout(function () {
                var bsAlert = bootstrap.Alert.getOrCreateInstance(alertEl);
                bsAlert.close();
            }, 6000);
        });
    }

    // ------------------------------------------------------------
    // Máscara simples de telefone (61) 90000-0000
    // ------------------------------------------------------------
    function initPhoneMask() {
        var phoneInputs = document.querySelectorAll('input[name="telefone"]');
        phoneInputs.forEach(function (input) {
            input.addEventListener('input', function () {
                var digits = input.value.replace(/\D/g, '').slice(0, 11);
                var formatted = digits;
                if (digits.length > 2) {
                    formatted = '(' + digits.slice(0, 2) + ') ' + digits.slice(2);
                }
                if (digits.length > 7) {
                    var isCel = digits.length > 10;
                    var splitAt = isCel ? 7 : 6;
                    formatted = '(' + digits.slice(0, 2) + ') ' + digits.slice(2, splitAt) + '-' + digits.slice(splitAt);
                }
                input.value = formatted;
            });
        });
    }

    // ------------------------------------------------------------
    // Confirmação extra antes de excluir (defesa em profundidade;
    // os modais já pedem confirmação, isso é um reforço opcional)
    // ------------------------------------------------------------
    function initDeleteButtonsFeedback() {
        document.querySelectorAll('form[action] input[name="acao"][value^="excluir_"]').forEach(function (input) {
            var form = input.closest('form');
            form.addEventListener('submit', function () {
                var btn = form.querySelector('button[type="submit"]');
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Processando...';
                }
            });
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        initFormValidation();
        initAutoDismissAlerts();
        initPhoneMask();
        initDeleteButtonsFeedback();
    });
})();
