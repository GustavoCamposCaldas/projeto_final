<?php
/**
 * Conecta Vagas DF - Configurações e Conexão com Banco de Dados
 * Versão 7.0
 *
 * Estabelece conexão PDO com MySQL. Caso o MySQL não esteja disponível
 * (ex.: ambiente sem XAMPP configurado), faz fallback automático para
 * um banco SQLite local em database/database.sqlite, criando as tabelas
 * e populando dados de teste automaticamente.
 */

// ------------------------------------------------------------
// Sessão
// ------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ------------------------------------------------------------
// Exibição de erros (ajuste para produção)
// ------------------------------------------------------------
error_reporting(E_ALL);
ini_set('display_errors', '1');
date_default_timezone_set('America/Sao_Paulo');

// ------------------------------------------------------------
// Constantes gerais do sistema
// ------------------------------------------------------------
define('SITE_NAME', 'Conecta Vagas DF');
define('SITE_VERSION', '7.0');

$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
define('BASE_URL', rtrim($scriptDir, '/') . '/');

// ------------------------------------------------------------
// Constantes do banco de dados (MySQL)
// ------------------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_NAME', 'conecta_vagas_df');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('SQLITE_PATH', __DIR__ . '/../database/database.sqlite');

define('DB_DRIVER', 'mysql'); // sobrescrito abaixo caso caia no fallback

/**
 * Cria a estrutura de tabelas e popula dados de teste no SQLite,
 * usada apenas quando o fallback é acionado.
 */
function conectaVagasDfCriarEstruturaSqlite(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS vagas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo VARCHAR(150) NOT NULL,
            empresa VARCHAR(150) NOT NULL,
            ra VARCHAR(60) NOT NULL,
            tipo_contrato VARCHAR(20) NOT NULL DEFAULT 'CLT',
            salario DECIMAL(10,2) DEFAULT 0,
            descricao TEXT NOT NULL,
            requisitos TEXT,
            vagas_disponiveis INTEGER NOT NULL DEFAULT 1,
            status VARCHAR(20) NOT NULL DEFAULT 'ativa',
            data_publicacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS candidatos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vaga_id INTEGER NOT NULL,
            nome VARCHAR(150) NOT NULL,
            email VARCHAR(150) NOT NULL,
            telefone VARCHAR(20) NOT NULL,
            ra VARCHAR(60) NOT NULL,
            mensagem TEXT,
            status VARCHAR(20) NOT NULL DEFAULT 'pendente',
            data_candidatura DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (vaga_id) REFERENCES vagas(id) ON DELETE CASCADE
        );
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome VARCHAR(150) NOT NULL,
            email VARCHAR(150) NOT NULL UNIQUE,
            senha VARCHAR(255) NOT NULL,
            telefone VARCHAR(20) DEFAULT '',
            ra VARCHAR(60) DEFAULT '',
            bio TEXT DEFAULT '',
            tipo VARCHAR(20) NOT NULL DEFAULT 'candidato',
            data_cadastro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
    ");

    // Popular usuários se a tabela estiver vazia
    $countUsers = (int) $pdo->query("SELECT COUNT(*) FROM usuarios")->fetchColumn();
    if ($countUsers === 0) {
        $stmtUser = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, telefone, ra, bio, tipo) VALUES (?, ?, ?, ?, ?, ?, ?)");
        
        // Administrador padrão (senha: admin123)
        $stmtUser->execute([
            'Administrador do Sistema',
            'admin@conectavagas.df',
            password_hash('admin123', PASSWORD_DEFAULT),
            '(61) 3300-0000',
            'Plano Piloto',
            'Conta de administração geral do Conecta Vagas DF.',
            'admin'
        ]);

        // Candidatos padrão (senha: 123456)
        $candidatosUsuarios = [
            ['Ana Paula Souza', 'ana.souza@email.com', '(61) 99123-4567', 'Plano Piloto', 'Desenvolvedora Júnior com foco em PHP, MySQL e desenvolvimento web.'],
            ['Carlos Eduardo Lima', 'carlos.lima@email.com', '(61) 98877-1122', 'Taguatinga', 'Formado em Ciência da Computação, buscando oportunidades em TI.'],
            ['Fernanda Alves', 'fernanda.alves@email.com', '(61) 99555-3344', 'Ceilândia', 'Profissional da área administrativa com experiência em atendimento ao público.'],
            ['Mariana Costa', 'mariana.costa@email.com', '(61) 99222-6677', 'Águas Claras', 'Desenvolvedora Full Stack com 3 anos de experiência.'],
        ];

        foreach ($candidatosUsuarios as $cu) {
            $stmtUser->execute([
                $cu[0],
                $cu[1],
                password_hash('123456', PASSWORD_DEFAULT),
                $cu[2],
                $cu[3],
                $cu[4],
                'candidato'
            ]);
        }
    }

    // Popular apenas se estiver vazio
    $count = (int) $pdo->query("SELECT COUNT(*) FROM vagas")->fetchColumn();
    if ($count === 0) {
        $vagas = [
            ['Analista de Sistemas Jr.', 'GovTech DF', 'Plano Piloto', 'CLT', 3800.00, 'Atuação no desenvolvimento e manutenção de sistemas internos da administração pública.', 'Graduação em TI, PHP e MySQL.', 2, 'ativa', '2026-08-01 09:00:00'],
            ['Auxiliar Administrativo', 'Comércio Ceilândia Ltda', 'Ceilândia', 'CLT', 1800.00, 'Rotinas administrativas e atendimento ao público.', 'Ensino médio completo, Excel básico.', 3, 'ativa', '2026-08-05 10:30:00'],
            ['Estágio em Marketing Digital', 'Agência Cerrado Criativo', 'Taguatinga', 'Estágio', 1200.00, 'Apoio na criação de campanhas e redes sociais.', 'Cursando Marketing ou Publicidade.', 1, 'ativa', '2026-08-10 14:00:00'],
            ['Desenvolvedor(a) Full Stack', 'Startup Cerrado Labs', 'Águas Claras', 'PJ', 7500.00, 'Desenvolvimento de aplicações web com PHP e JavaScript.', 'Experiência com PHP, JS e Git.', 1, 'ativa', '2026-08-12 08:00:00'],
            ['Vendedor(a) de Loja', 'Shopping Gama Center', 'Gama', 'CLT', 1600.00, 'Atendimento ao cliente e reposição de mercadorias.', 'Disponibilidade de horário.', 4, 'ativa', '2026-08-14 11:00:00'],
            ['Motorista Entregador', 'Log Express Samambaia', 'Samambaia', 'Temporário', 2200.00, 'Entrega de mercadorias na região administrativa.', 'CNH categoria B.', 2, 'ativa', '2026-08-15 07:30:00'],
            ['Recepcionista Bilíngue', 'Hotel Brasília Palace', 'Plano Piloto', 'CLT', 2400.00, 'Recepção e atendimento a hóspedes.', 'Inglês intermediário.', 1, 'ativa', '2026-08-16 09:15:00'],
            ['Assistente Contábil', 'Contabilidade Planalto', 'Sobradinho', 'CLT', 2600.00, 'Lançamentos contábeis e conciliação bancária.', 'Cursando Ciências Contábeis.', 1, 'inativa', '2026-07-20 10:00:00'],
            ['Estágio em Engenharia Civil', 'Construtora Cerrado Vivo', 'Guará', 'Estágio', 1400.00, 'Apoio na fiscalização de obras.', 'Cursando Engenharia Civil.', 2, 'ativa', '2026-08-18 13:00:00'],
            ['Cozinheiro(a)', 'Restaurante Sabor do Cerrado', 'Núcleo Bandeirante', 'CLT', 2000.00, 'Preparo de pratos e organização da cozinha.', 'Experiência em cozinha profissional.', 2, 'ativa', '2026-08-19 06:00:00'],
        ];

        $stmt = $pdo->prepare("INSERT INTO vagas (titulo, empresa, ra, tipo_contrato, salario, descricao, requisitos, vagas_disponiveis, status, data_publicacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($vagas as $v) {
            $stmt->execute($v);
        }

        $candidatos = [
            [1, 'Ana Paula Souza', 'ana.souza@email.com', '(61) 99123-4567', 'Plano Piloto', 'Tenho experiência com PHP e MySQL.', 'entrevista', '2026-08-02 10:00:00'],
            [1, 'Carlos Eduardo Lima', 'carlos.lima@email.com', '(61) 98877-1122', 'Taguatinga', 'Buscando primeira oportunidade na área.', 'pendente', '2026-08-03 15:20:00'],
            [2, 'Fernanda Alves', 'fernanda.alves@email.com', '(61) 99555-3344', 'Ceilândia', 'Já trabalhei com atendimento ao público.', 'aprovado', '2026-08-06 09:00:00'],
            [3, 'João Victor Santos', 'joao.santos@email.com', '(61) 98111-9988', 'Taguatinga', 'Cursando Publicidade, disponível para estágio.', 'em_analise', '2026-08-11 08:45:00'],
            [4, 'Mariana Costa', 'mariana.costa@email.com', '(61) 99222-6677', 'Águas Claras', 'Desenvolvedora com 3 anos de experiência.', 'entrevista', '2026-08-13 12:00:00'],
            [5, 'Pedro Henrique Rocha', 'pedro.rocha@email.com', '(61) 98333-4455', 'Gama', 'Experiência anterior em loja de departamentos.', 'pendente', '2026-08-15 16:30:00'],
            [6, 'Lucas Martins', 'lucas.martins@email.com', '(61) 99444-2211', 'Samambaia', 'CNH B há 3 anos e experiência com entregas.', 'rejeitado', '2026-08-16 07:50:00'],
            [1, 'Beatriz Ferreira', 'beatriz.ferreira@email.com', '(61) 98666-7788', 'Sobradinho', 'Certificação em desenvolvimento web.', 'pendente', '2026-08-17 11:10:00'],
        ];
        $stmt2 = $pdo->prepare("INSERT INTO candidatos (vaga_id, nome, email, telefone, ra, mensagem, status, data_candidatura) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($candidatos as $c) {
            $stmt2->execute($c);
        }
    }
}

// ------------------------------------------------------------
// Conexão principal (MySQL) com fallback automático para SQLite
// ------------------------------------------------------------
$pdoOptions = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $pdoOptions);
} catch (PDOException $e) {
    // Fallback automático para SQLite quando o MySQL não está disponível
    $pdo = new PDO('sqlite:' . SQLITE_PATH, null, null, $pdoOptions);
    $pdo->exec('PRAGMA foreign_keys = ON;');
    conectaVagasDfCriarEstruturaSqlite($pdo);
    define('DB_DRIVER_ATIVO', 'sqlite');
}

if (!defined('DB_DRIVER_ATIVO')) {
    define('DB_DRIVER_ATIVO', 'mysql');
}
