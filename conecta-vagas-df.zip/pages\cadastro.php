﻿<?php
if (isLoggedIn()) {
    redirect(BASE_URL . '?page=perfil');
}

// Processar Cadastro
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'cadastrar') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Token de segurança expirado. Tente novamente.');
        redirect(BASE_URL . '?page=cadastro');
    }

    $nome            = sanitizeInput($_POST['nome'] ?? '');
    $email           = sanitizeInput($_POST['email'] ?? '');
    $senha           = $_POST['senha'] ?? '';
    $confirmarSenha  = $_POST['confirmar_senha'] ?? '';
    $telefone        = sanitizeInput($_POST['telefone'] ?? '');
    $ra              = sanitizeInput($_POST['ra'] ?? '');
    $bio             = sanitizeInput($_POST['bio'] ?? '');

    $erros = [];
    if (mb_strlen($nome) < 3) $erros[] = 'Informe seu nome completo.';
    if (!validateEmail($email)) $erros[] = 'Informe um e-mail válido.';
    if (mb_strlen($senha) < 6) $erros[] = 'A senha deve ter pelo menos 6 caracteres.';
    if ($senha !== $confirmarSenha) $erros[] = 'As senhas não coincidem.';
    if (!validatePhone($telefone)) $erros[] = 'Informe um telefone válido com DDD.';
    if (!in_array($ra, getRegioesAdministrativas(), true)) $erros[] = 'Selecione sua Região Administrativa (RA).';

    if (getUsuarioByEmail($email)) {
        $erros[] = 'Este e-mail já está cadastrado. Faça login para continuar.';
    }

    if (empty($erros)) {
        $novoId = cadastrarUsuario([
            'nome'     => $nome,
            'email'    => $email,
            'senha'    => $senha,
            'telefone' => $telefone,
            'ra'       => $ra,
            'bio'      => $bio,
            'tipo'     => 'candidato',
        ]);

        loginUsuario($email, $senha);
        setFlashMessage('success', 'Cadastro realizado com sucesso! Bem-vindo(a), ' . e($nome) . '!');
        redirect(BASE_URL . '?page=perfil');
    } else {
        setFlashMessage('danger', implode('<br>', $erros));
        redirect(BASE_URL . '?page=cadastro');
    }
}
?>

<div class="row justify-content-center my-4">
    <div class="col-md-8 col-lg-7">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4 p-md-5">
                <div class="text-center mb-4">
                    <i class="bi bi-person-plus-fill text-success display-5"></i>
                    <h1 class="h3 fw-bold mt-2 mb-1">Cadastro de Candidato</h1>
                    <p class="text-muted small">Crie sua conta para se candidatar às vagas e acompanhar seus processos seletivos.</p>
                </div>

                <form method="POST" action="<?= e(BASE_URL) ?>?page=cadastro" class="needs-validation" novalidate>
                    <?= csrfField() ?>
                    <input type="hidden" name="acao" value="cadastrar">

                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label fw-semibold">Nome Completo *</label>
                            <input type="text" name="nome" class="form-control" placeholder="Ex: Maria Silva" required minlength="3">
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">E-mail *</label>
                            <input type="email" name="email" class="form-control" placeholder="maria@exemplo.com" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Telefone / WhatsApp *</label>
                            <input type="text" name="telefone" class="form-control" placeholder="(61) 90000-0000" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Senha (mínimo 6 caracteres) *</label>
                            <input type="password" name="senha" class="form-control" required minlength="6">
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Confirmar Senha *</label>
                            <input type="password" name="confirmar_senha" class="form-control" required minlength="6">
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold">Região Administrativa (RA do DF) *</label>
                            <select name="ra" class="form-select" required>
                                <option value="">Selecione sua cidade/região...</option>
                                <?php foreach (getRegioesAdministrativas() as $raItem): ?>
                                    <option value="<?= e($raItem) ?>"><?= e($raItem) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold">Mini-currículo / Apresentação Profissional</label>
                            <textarea name="bio" class="form-control" rows="3" placeholder="Fale brevemente sobre suas qualificações, área de atuação e objetivos..."></textarea>
                            <div class="form-text small">Essas informações serão usadas para agilizar suas candidaturas às vagas.</div>
                        </div>

                        <div class="col-12 mt-4">
                            <button type="submit" class="btn btn-success w-100 py-2 fw-semibold">
                                <i class="bi bi-check-circle-fill"></i> Criar Minha Conta
                            </button>
                        </div>
                    </div>
                </form>

                <hr class="my-4">

                <div class="text-center">
                    <p class="small text-muted mb-0">Já possui uma conta? <a href="<?= e(BASE_URL) ?>?page=login" class="fw-semibold">Faça Login</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
