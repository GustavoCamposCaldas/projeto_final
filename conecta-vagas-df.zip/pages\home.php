<?php
$stats = getDashboardStats();
$vagasDestaque = getVagasDestaque(3);
$statusVaga = getStatusVagaOpcoes();
?>

<section class="cvdf-hero rounded-4 p-5 mb-5 text-center text-white">
    <h1 class="display-5 fw-bold mb-3"><i class="bi bi-geo-alt-fill"></i> Conecta Vagas DF</h1>
    <p class="lead mb-4">O portal que conecta candidatos e empresas em todas as Regiões Administrativas do Distrito Federal.</p>
    <a href="<?= e(BASE_URL) ?>?page=vagas" class="btn btn-warning btn-lg fw-semibold">
        <i class="bi bi-search"></i> Ver Vagas Disponíveis
    </a>
</section>

<div class="row g-3 mb-5">
    <div class="col-6 col-md-3">
        <div class="card cvdf-stat-card h-100 text-center shadow-sm border-0">
            <div class="card-body">
                <i class="bi bi-briefcase-fill fs-2 text-primary"></i>
                <h3 class="fw-bold mt-2 mb-0"><?= (int) $stats['vagas_ativas'] ?></h3>
                <p class="text-muted small mb-0">Vagas Ativas</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card cvdf-stat-card h-100 text-center shadow-sm border-0">
            <div class="card-body">
                <i class="bi bi-people-fill fs-2 text-success"></i>
                <h3 class="fw-bold mt-2 mb-0"><?= (int) $stats['total_candidatos'] ?></h3>
                <p class="text-muted small mb-0">Candidatos</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card cvdf-stat-card h-100 text-center shadow-sm border-0">
            <div class="card-body">
                <i class="bi bi-map-fill fs-2 text-warning"></i>
                <h3 class="fw-bold mt-2 mb-0"><?= (int) $stats['total_ras'] ?></h3>
                <p class="text-muted small mb-0">Regiões Atendidas</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card cvdf-stat-card h-100 text-center shadow-sm border-0">
            <div class="card-body">
                <i class="bi bi-building-fill fs-2 text-info"></i>
                <h3 class="fw-bold mt-2 mb-0"><?= (int) $stats['total_vagas'] ?></h3>
                <p class="text-muted small mb-0">Total de Vagas</p>
            </div>
        </div>
    </div>
</div>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="h4 fw-bold mb-0"><i class="bi bi-star-fill text-warning"></i> Vagas em Destaque</h2>
    <a href="<?= e(BASE_URL) ?>?page=vagas" class="small">Ver todas <i class="bi bi-arrow-right"></i></a>
</div>

<?php if (empty($vagasDestaque)): ?>
    <div class="alert alert-secondary">Nenhuma vaga disponível no momento.</div>
<?php else: ?>
    <div class="row g-4">
        <?php foreach ($vagasDestaque as $vaga): ?>
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 cvdf-vaga-card">
                    <div class="card-body d-flex flex-column">
                        <span class="badge bg-<?= e($statusVaga[$vaga['status']]['class'] ?? 'secondary') ?> align-self-start mb-2">
                            <?= e($statusVaga[$vaga['status']]['label'] ?? $vaga['status']) ?>
                        </span>
                        <h5 class="card-title fw-bold"><?= e($vaga['titulo']) ?></h5>
                        <p class="card-subtitle text-muted mb-2"><i class="bi bi-building"></i> <?= e($vaga['empresa']) ?></p>
                        <p class="small mb-1"><i class="bi bi-geo-alt"></i> <?= e($vaga['ra']) ?></p>
                        <p class="small mb-3"><i class="bi bi-file-text"></i> <?= e($vaga['tipo_contrato']) ?> &middot; <?= formatSalario($vaga['salario']) ?></p>
                        <p class="card-text small text-muted flex-grow-1"><?= e(truncateText($vaga['descricao'], 110)) ?></p>
                        <a href="<?= e(BASE_URL) ?>?page=vaga&id=<?= (int) $vaga['id'] ?>" class="btn btn-outline-primary btn-sm mt-2">
                            Ver Detalhes <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
