﻿<?php
if (isLoggedIn()) {
    if (isAdmin()) {
        redirect(BASE_URL . '?page=dashboard');
    } else {
        redirect(BASE_URL . '?page=perfil');
    }
}

// Processar Login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'login') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Token de segurança expirado. Tente novamente.');
        redirect(BASE_URL . '?page=login');
    }

    $email = sanitizeInput($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (empty($email) || empty($senha)) {
        setFlashMessage('danger', 'Preencha o e-mail e a senha.');
        redirect(BASE_URL . '?page=login');
    }

    if (loginUsuario($email, $senha)) {
        $usuario = getUsuarioLogado();
        if ($usuario['tipo'] === 'admin') {
            setFlashMessage('success', 'Bem-vindo(a), Administrador(a)!');
            redirect(BASE_URL . '?page=dashboard');
        } else {
            setFlashMessage('success', 'Bem-vindo(a) de volta, ' . e($usuario['nome']) . '!');
            redirect(BASE_URL . '?page=perfil');
        }
    } else {
        setFlashMessage('danger', 'E-mail ou senha inválidos. Verifique seus dados.');
        redirect(BASE_URL . '?page=login');
    }
}
?>

<div class="row justify-content-center my-4">
    <div class="col-md-6 col-lg-5">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <div class="text-center mb-4">
                    <i class="bi bi-person-lock text-primary display-5"></i>
                    <h1 class="h4 fw-bold mt-2 mb-1">Acessar Sistema</h1>
                    <p class="text-muted small">Entre como Candidato ou Administrador</p>
                </div>

                <form method="POST" action="<?= e(BASE_URL) ?>?page=login" class="needs-validation" novalidate>
                    <?= csrfField() ?>
                    <input type="hidden" name="acao" value="login">

                    <div class="mb-3">
                        <label class="form-label fw-semibold">E-mail</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                            <input type="email" name="email" id="loginEmail" class="form-control" placeholder="seu.email@exemplo.com" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold">Senha</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-key"></i></span>
                            <input type="password" name="senha" id="loginSenha" class="form-control" placeholder="Sua senha" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                        <i class="bi bi-box-arrow-in-right"></i> Entrar
                    </button>
                </form>

                <hr class="my-4">

                <div class="text-center mb-3">
                    <p class="small text-muted mb-2">Ainda não tem cadastro como candidato?</p>
                    <a href="<?= e(BASE_URL) ?>?page=cadastro" class="btn btn-outline-success btn-sm w-100">
                        <i class="bi bi-person-plus"></i> Criar Conta de Candidato
                    </a>
                </div>

                <!-- Acesso rápido para testes -->
                <div class="bg-light p-3 rounded-3 small">
                    <div class="fw-bold mb-2 text-secondary"><i class="bi bi-lightning-charge-fill text-warning"></i> Contas de Demonstração (Clique para preencher):</div>
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-sm btn-outline-dark text-start" onclick="preencherLogin('admin@conectavagas.df', 'admin123')">
                            🛡️ <strong>Administrador:</strong> admin@conectavagas.df / admin123
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-primary text-start" onclick="preencherLogin('ana.souza@email.com', '123456')">
                            👤 <strong>Candidata (Ana Paula):</strong> ana.souza@email.com / 123456
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-secondary text-start" onclick="preencherLogin('carlos.lima@email.com', '123456')">
                            👤 <strong>Candidato (Carlos):</strong> carlos.lima@email.com / 123456
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function preencherLogin(email, senha) {
    document.getElementById('loginEmail').value = email;
    document.getElementById('loginSenha').value = senha;
}
</script>
