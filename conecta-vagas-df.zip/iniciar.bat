@echo off
chcp 65001 >nul
title Conecta Vagas DF - Servidor Local
echo ===================================================
echo    Conecta Vagas DF (Sem XAMPP)
echo ===================================================
echo.

where php >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set PHP_CMD=php
) else if exist "%LOCALAPPDATA%\Programs\php\php.exe" (
    set "PHP_CMD=%LOCALAPPDATA%\Programs\php\php.exe"
) else (
    echo [ERRO] PHP nao encontrado.
    pause
    exit /b 1
)

echo Servidor local ativo em: http://localhost:8000
echo Pressione CTRL+C para encerrar o servidor.
echo.

start http://localhost:8000
%PHP_CMD% -S localhost:8000
