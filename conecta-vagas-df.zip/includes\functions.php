<?php
/**
 * Conecta Vagas DF - Funções Utilitárias
 * Versão 7.0
 *
 * Contém as funções obrigatórias de segurança (CSRF, sanitização/XSS)
 * e todas as funções de CRUD para vagas e candidatos.
 */

// ============================================================
// 1. SEGURANÇA: CSRF
// ============================================================

/**
 * Gera (ou reaproveita) um token CSRF armazenado na sessão
 * e retorna o valor para ser usado em formulários.
 */
function generateCSRFToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Valida o token CSRF recebido de um formulário contra o
 * token armazenado na sessão, usando comparação segura.
 */
function validateCSRFToken(?string $token): bool
{
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Imprime um campo <input type="hidden"> pronto para uso em formulários.
 */
function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(generateCSRFToken()) . '">';
}

// ============================================================
// 2. SEGURANÇA: SANITIZAÇÃO E PROTEÇÃO CONTRA XSS
// ============================================================

/**
 * Sanitiza uma entrada de texto vinda do usuário (remove espaços
 * nas pontas e neutraliza tags/scripts). Use para todo dado antes
 * de gravar no banco.
 */
function sanitizeInput($data)
{
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    $data = trim((string) $data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    return $data;
}

/**
 * Escapa uma string para exibição segura em HTML, prevenindo XSS.
 * Deve ser usada em TODO dado dinâmico impresso nas views.
 */
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/**
 * Valida formato de e-mail.
 */
function validateEmail(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Valida telefone no formato brasileiro (aceita variações comuns).
 */
function validatePhone(string $phone): bool
{
    $digits = preg_replace('/\D/', '', $phone);
    return strlen($digits) >= 10 && strlen($digits) <= 11;
}

/**
 * Sanitiza e converte um valor para inteiro seguro (>= 0).
 */
function sanitizeInt($value): int
{
    return max(0, (int) filter_var($value, FILTER_SANITIZE_NUMBER_INT));
}

/**
 * Sanitiza e converte um valor monetário para float seguro (>= 0).
 */
function sanitizeFloat($value): float
{
    $value = str_replace(',', '.', (string) $value);
    $clean = filter_var($value, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    return max(0, (float) $clean);
}

// ============================================================
// 3. MENSAGENS FLASH
// ============================================================

function setFlashMessage(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlashMessage(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

// ============================================================
// 4. HELPERS GERAIS
// ============================================================

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function formatDate(string $date): string
{
    $timestamp = strtotime($date);
    return $timestamp ? date('d/m/Y \à\s H:i', $timestamp) : '-';
}

function formatSalario($value): string
{
    return 'R$ ' . number_format((float) $value, 2, ',', '.');
}

/**
 * Trunca um texto de forma segura, com reticências, sem depender
 * obrigatoriamente da extensão mbstring (usa fallback se ausente).
 */
function truncateText(string $texto, int $limite = 100): string
{
    if (function_exists('mb_strimwidth')) {
        return mb_strimwidth($texto, 0, $limite, '...', 'UTF-8');
    }
    return strlen($texto) > $limite ? substr($texto, 0, $limite) . '...' : $texto;
}

function getRegioesAdministrativas(): array
{
    return [
        'Plano Piloto', 'Gama', 'Taguatinga', 'Brazlândia', 'Sobradinho',
        'Planaltina', 'Paranoá', 'Núcleo Bandeirante', 'Ceilândia', 'Guará',
        'Cruzeiro', 'Samambaia', 'Santa Maria', 'São Sebastião', 'Recanto das Emas',
        'Lago Sul', 'Riacho Fundo', 'Lago Norte', 'Candangolândia', 'Águas Claras',
        'Riacho Fundo II', 'Sudoeste/Octogonal', 'Varjão', 'Park Way', 'SCIA/Estrutural',
        'Sobradinho II', 'Jardim Botânico', 'Itapoã', 'SIA', 'Vicente Pires',
        'Fercal', 'Sol Nascente/Pôr do Sol', 'Arniqueira',
    ];
}

function getTiposContrato(): array
{
    return ['CLT', 'PJ', 'Estágio', 'Temporário', 'Freelancer'];
}

function getStatusCandidaturaOpcoes(): array
{
    return [
        'pendente'   => ['label' => 'Pendente',    'class' => 'secondary'],
        'em_analise' => ['label' => 'Em Análise',  'class' => 'info'],
        'entrevista' => ['label' => 'Entrevista',  'class' => 'primary'],
        'aprovado'   => ['label' => 'Aprovado',    'class' => 'success'],
        'rejeitado'  => ['label' => 'Rejeitado',   'class' => 'danger'],
    ];
}

function getStatusVagaOpcoes(): array
{
    return [
        'ativa'     => ['label' => 'Ativa',     'class' => 'success'],
        'inativa'   => ['label' => 'Inativa',   'class' => 'secondary'],
        'encerrada' => ['label' => 'Encerrada', 'class' => 'danger'],
    ];
}

// ============================================================
// 5. CRUD - VAGAS
// ============================================================

/**
 * Lista vagas com filtros opcionais (ra, tipo_contrato, busca, status).
 */
function getAllVagas(array $filtros = []): array
{
    global $pdo;

    $sql = "SELECT v.*,
                   (SELECT COUNT(*) FROM candidatos c WHERE c.vaga_id = v.id) AS total_candidatos
            FROM vagas v WHERE 1=1";
    $params = [];

    if (!empty($filtros['ra'])) {
        $sql .= " AND v.ra = :ra";
        $params[':ra'] = $filtros['ra'];
    }
    if (!empty($filtros['tipo_contrato'])) {
        $sql .= " AND v.tipo_contrato = :tipo_contrato";
        $params[':tipo_contrato'] = $filtros['tipo_contrato'];
    }
    if (!empty($filtros['status'])) {
        $sql .= " AND v.status = :status";
        $params[':status'] = $filtros['status'];
    } elseif (empty($filtros['incluir_todas'])) {
        $sql .= " AND v.status = 'ativa'";
    }
    if (!empty($filtros['busca'])) {
        $sql .= " AND (v.titulo LIKE :busca OR v.empresa LIKE :busca)";
        $params[':busca'] = '%' . $filtros['busca'] . '%';
    }

    $sql .= " ORDER BY v.data_publicacao DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getVagaById(int $id): ?array
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM vagas WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $vaga = $stmt->fetch();
    return $vaga ?: null;
}

function getVagasDestaque(int $limite = 3): array
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM vagas WHERE status = 'ativa' ORDER BY data_publicacao DESC LIMIT :lim");
    $stmt->bindValue(':lim', $limite, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * Cria uma nova vaga. Recebe dados já sanitizados.
 * Retorna o ID inserido ou lança PDOException em caso de erro.
 */
function createVaga(array $dados): int
{
    global $pdo;
    $stmt = $pdo->prepare("
        INSERT INTO vagas (titulo, empresa, ra, tipo_contrato, salario, descricao, requisitos, vagas_disponiveis, status, data_publicacao)
        VALUES (:titulo, :empresa, :ra, :tipo_contrato, :salario, :descricao, :requisitos, :vagas_disponiveis, :status, :data_publicacao)
    ");
    $stmt->execute([
        ':titulo'            => $dados['titulo'],
        ':empresa'           => $dados['empresa'],
        ':ra'                => $dados['ra'],
        ':tipo_contrato'     => $dados['tipo_contrato'],
        ':salario'           => $dados['salario'],
        ':descricao'         => $dados['descricao'],
        ':requisitos'        => $dados['requisitos'] ?? '',
        ':vagas_disponiveis' => $dados['vagas_disponiveis'],
        ':status'            => $dados['status'] ?? 'ativa',
        ':data_publicacao'   => date('Y-m-d H:i:s'),
    ]);
    return (int) $pdo->lastInsertId();
}

function updateVaga(int $id, array $dados): bool
{
    global $pdo;
    $stmt = $pdo->prepare("
        UPDATE vagas SET titulo = :titulo, empresa = :empresa, ra = :ra, tipo_contrato = :tipo_contrato,
               salario = :salario, descricao = :descricao, requisitos = :requisitos,
               vagas_disponiveis = :vagas_disponiveis, status = :status
        WHERE id = :id
    ");
    return $stmt->execute([
        ':titulo'            => $dados['titulo'],
        ':empresa'           => $dados['empresa'],
        ':ra'                => $dados['ra'],
        ':tipo_contrato'     => $dados['tipo_contrato'],
        ':salario'           => $dados['salario'],
        ':descricao'         => $dados['descricao'],
        ':requisitos'        => $dados['requisitos'] ?? '',
        ':vagas_disponiveis' => $dados['vagas_disponiveis'],
        ':status'            => $dados['status'],
        ':id'                => $id,
    ]);
}

function updateVagaStatus(int $id, string $status): bool
{
    global $pdo;
    $permitido = array_keys(getStatusVagaOpcoes());
    if (!in_array($status, $permitido, true)) {
        return false;
    }
    $stmt = $pdo->prepare("UPDATE vagas SET status = :status WHERE id = :id");
    return $stmt->execute([':status' => $status, ':id' => $id]);
}

function deleteVaga(int $id): bool
{
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM vagas WHERE id = :id");
    return $stmt->execute([':id' => $id]);
}

function countVagasAtivas(): int
{
    global $pdo;
    return (int) $pdo->query("SELECT COUNT(*) FROM vagas WHERE status = 'ativa'")->fetchColumn();
}

// ============================================================
// 6. CRUD - CANDIDATOS
// ============================================================

/**
 * Lista candidatos com filtros opcionais (status, vaga_id, busca).
 * Inclui dados da vaga associada via JOIN.
 */
function getAllCandidatos(array $filtros = []): array
{
    global $pdo;

    $sql = "SELECT c.*, v.titulo AS vaga_titulo, v.empresa AS vaga_empresa
            FROM candidatos c
            INNER JOIN vagas v ON v.id = c.vaga_id
            WHERE 1=1";
    $params = [];

    if (!empty($filtros['status'])) {
        $sql .= " AND c.status = :status";
        $params[':status'] = $filtros['status'];
    }
    if (!empty($filtros['vaga_id'])) {
        $sql .= " AND c.vaga_id = :vaga_id";
        $params[':vaga_id'] = $filtros['vaga_id'];
    }
    if (!empty($filtros['busca'])) {
        $sql .= " AND (c.nome LIKE :busca OR c.email LIKE :busca)";
        $params[':busca'] = '%' . $filtros['busca'] . '%';
    }

    $sql .= " ORDER BY c.data_candidatura DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getCandidatoById(int $id): ?array
{
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT c.*, v.titulo AS vaga_titulo, v.empresa AS vaga_empresa
        FROM candidatos c INNER JOIN vagas v ON v.id = c.vaga_id
        WHERE c.id = :id
    ");
    $stmt->execute([':id' => $id]);
    $candidato = $stmt->fetch();
    return $candidato ?: null;
}

/**
 * Registra uma candidatura para uma vaga. Retorna o ID inserido.
 */
function createCandidatura(array $dados): int
{
    global $pdo;
    $stmt = $pdo->prepare("
        INSERT INTO candidatos (vaga_id, nome, email, telefone, ra, mensagem, status, data_candidatura)
        VALUES (:vaga_id, :nome, :email, :telefone, :ra, :mensagem, 'pendente', :data_candidatura)
    ");
    $stmt->execute([
        ':vaga_id'         => $dados['vaga_id'],
        ':nome'            => $dados['nome'],
        ':email'           => $dados['email'],
        ':telefone'        => $dados['telefone'],
        ':ra'              => $dados['ra'],
        ':mensagem'        => $dados['mensagem'] ?? '',
        ':data_candidatura' => date('Y-m-d H:i:s'),
    ]);
    return (int) $pdo->lastInsertId();
}

function updateCandidatoStatus(int $id, string $status): bool
{
    global $pdo;
    $permitido = array_keys(getStatusCandidaturaOpcoes());
    if (!in_array($status, $permitido, true)) {
        return false;
    }
    $stmt = $pdo->prepare("UPDATE candidatos SET status = :status WHERE id = :id");
    return $stmt->execute([':status' => $status, ':id' => $id]);
}

function deleteCandidato(int $id): bool
{
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM candidatos WHERE id = :id");
    return $stmt->execute([':id' => $id]);
}

function countCandidatosTotal(): int
{
    global $pdo;
    return (int) $pdo->query("SELECT COUNT(*) FROM candidatos")->fetchColumn();
}

function countCandidatosPorStatus(): array
{
    global $pdo;
    $stmt = $pdo->query("SELECT status, COUNT(*) AS total FROM candidatos GROUP BY status");
    $resultado = array_fill_keys(array_keys(getStatusCandidaturaOpcoes()), 0);
    foreach ($stmt->fetchAll() as $row) {
        $resultado[$row['status']] = (int) $row['total'];
    }
    return $resultado;
}

// ============================================================
// 7. DASHBOARD / ESTATÍSTICAS
// ============================================================

function getDashboardStats(): array
{
    global $pdo;

    $stats = [
        'total_vagas'        => (int) $pdo->query("SELECT COUNT(*) FROM vagas")->fetchColumn(),
        'vagas_ativas'       => countVagasAtivas(),
        'total_candidatos'   => countCandidatosTotal(),
        'total_ras'          => (int) $pdo->query("SELECT COUNT(DISTINCT ra) FROM vagas")->fetchColumn(),
        'por_status'         => countCandidatosPorStatus(),
    ];

    // Vagas por RA
    $stmt = $pdo->query("SELECT ra, COUNT(*) AS total FROM vagas GROUP BY ra ORDER BY total DESC");
    $stats['vagas_por_ra'] = $stmt->fetchAll();

    // Vagas por tipo de contrato
    $stmt2 = $pdo->query("SELECT tipo_contrato, COUNT(*) AS total FROM vagas GROUP BY tipo_contrato ORDER BY total DESC");
    $stats['vagas_por_tipo'] = $stmt2->fetchAll();

    // Vagas com mais candidaturas
    $stmt3 = $pdo->query("
        SELECT v.id, v.titulo, v.empresa, COUNT(c.id) AS total_candidatos
        FROM vagas v LEFT JOIN candidatos c ON c.vaga_id = v.id
        GROUP BY v.id, v.titulo, v.empresa
        ORDER BY total_candidatos DESC
        LIMIT 5
    ");
    $stats['top_vagas'] = $stmt3->fetchAll();

    return $stats;
}

// ============================================================
// 8. AUTENTICAÇÃO E CONTROLE DE ACESSO (USUÁRIOS)
// ============================================================

function getUsuarioLogado(): ?array
{
    if (!empty($_SESSION['usuario_id'])) {
        return getUsuarioById((int) $_SESSION['usuario_id']);
    }
    return null;
}

function isLoggedIn(): bool
{
    return !empty($_SESSION['usuario_id']);
}

function isAdmin(): bool
{
    $usuario = getUsuarioLogado();
    return $usuario && ($usuario['tipo'] === 'admin');
}

function isCandidato(): bool
{
    $usuario = getUsuarioLogado();
    return $usuario && ($usuario['tipo'] === 'candidato');
}

function requireLogin(): void
{
    if (!isLoggedIn()) {
        setFlashMessage('warning', 'Você precisa estar logado para acessar esta página.');
        redirect(BASE_URL . '?page=login');
    }
}

function requireAdmin(): void
{
    if (!isAdmin()) {
        setFlashMessage('danger', 'Acesso restrito para administradores.');
        redirect(BASE_URL . '?page=home');
    }
}

function requireCandidato(): void
{
    if (!isCandidato() && !isAdmin()) {
        setFlashMessage('warning', 'Acesse como candidato para visualizar esta área.');
        redirect(BASE_URL . '?page=login');
    }
}

function loginUsuario(string $email, string $senha): bool
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => $email]);
    $usuario = $stmt->fetch();

    if ($usuario && password_verify($senha, $usuario['senha'])) {
        $_SESSION['usuario_id'] = (int) $usuario['id'];
        $_SESSION['usuario_nome'] = $usuario['nome'];
        $_SESSION['usuario_email'] = $usuario['email'];
        $_SESSION['usuario_tipo'] = $usuario['tipo'];
        return true;
    }
    return false;
}

function logoutUsuario(): void
{
    unset($_SESSION['usuario_id'], $_SESSION['usuario_nome'], $_SESSION['usuario_email'], $_SESSION['usuario_tipo']);
    if (!headers_sent()) {
        session_regenerate_id(true);
    }
}

function getUsuarioById(int $id): ?array
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT id, nome, email, telefone, ra, bio, tipo, data_cadastro FROM usuarios WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $usuario = $stmt->fetch();
    return $usuario ?: null;
}

function getUsuarioByEmail(string $email): ?array
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT id, nome, email, telefone, ra, bio, tipo, data_cadastro FROM usuarios WHERE email = :email");
    $stmt->execute([':email' => $email]);
    $usuario = $stmt->fetch();
    return $usuario ?: null;
}

function cadastrarUsuario(array $dados): int
{
    global $pdo;
    $stmt = $pdo->prepare("
        INSERT INTO usuarios (nome, email, senha, telefone, ra, bio, tipo, data_cadastro)
        VALUES (:nome, :email, :senha, :telefone, :ra, :bio, :tipo, :data_cadastro)
    ");
    $stmt->execute([
        ':nome'          => $dados['nome'],
        ':email'         => $dados['email'],
        ':senha'         => password_hash($dados['senha'], PASSWORD_DEFAULT),
        ':telefone'      => $dados['telefone'] ?? '',
        ':ra'            => $dados['ra'] ?? '',
        ':bio'           => $dados['bio'] ?? '',
        ':tipo'          => $dados['tipo'] ?? 'candidato',
        ':data_cadastro' => date('Y-m-d H:i:s'),
    ]);
    return (int) $pdo->lastInsertId();
}

function atualizarPerfilUsuario(int $id, array $dados): bool
{
    global $pdo;
    $stmt = $pdo->prepare("
        UPDATE usuarios
        SET nome = :nome, telefone = :telefone, ra = :ra, bio = :bio
        WHERE id = :id
    ");
    return $stmt->execute([
        ':nome'     => $dados['nome'],
        ':telefone' => $dados['telefone'] ?? '',
        ':ra'       => $dados['ra'] ?? '',
        ':bio'      => $dados['bio'] ?? '',
        ':id'       => $id,
    ]);
}

function atualizarSenhaUsuario(int $id, string $novaSenha): bool
{
    global $pdo;
    $stmt = $pdo->prepare("UPDATE usuarios SET senha = :senha WHERE id = :id");
    return $stmt->execute([
        ':senha' => password_hash($novaSenha, PASSWORD_DEFAULT),
        ':id'    => $id,
    ]);
}

// ============================================================
// 9. CANDIDATURAS DO CANDIDATO
// ============================================================

function getCandidaturasPorEmail(string $email): array
{
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT c.*, v.titulo AS vaga_titulo, v.empresa AS vaga_empresa, v.ra AS vaga_ra,
               v.tipo_contrato AS vaga_tipo, v.salario AS vaga_salario, v.status AS vaga_status
        FROM candidatos c
        INNER JOIN vagas v ON v.id = c.vaga_id
        WHERE c.email = :email
        ORDER BY c.data_candidatura DESC
    ");
    $stmt->execute([':email' => $email]);
    return $stmt->fetchAll();
}

function usuarioJaCandidatou(int $vagaId, string $email): ?array
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM candidatos WHERE vaga_id = :vaga_id AND email = :email LIMIT 1");
    $stmt->execute([':vaga_id' => $vagaId, ':email' => $email]);
    $res = $stmt->fetch();
    return $res ?: null;
}

function cancelarCandidatura(int $candidaturaId, string $email): bool
{
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM candidatos WHERE id = :id AND email = :email");
    return $stmt->execute([':id' => $candidaturaId, ':email' => $email]);
}

