<?php
$currentPage = isset($_GET['page']) ? $_GET['page'] : 'home';
$flash = getFlashMessage();
$usuarioLogado = getUsuarioLogado();
$isAdminUser = isAdmin();
$isCandidatoUser = isCandidato();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e(SITE_NAME) ?> - Vagas de Emprego no Distrito Federal</title>
    <meta name="description" content="Portal de vagas de emprego para todas as Regiões Administrativas do Distrito Federal.">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <!-- Estilos customizados -->
    <link rel="stylesheet" href="<?= e(BASE_URL) ?>assets/css/style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top cvdf-navbar">
    <div class="container">
        <a class="navbar-brand fw-bold d-flex align-items-center gap-2" href="<?= e(BASE_URL) ?>">
            <i class="bi bi-geo-alt-fill"></i> Conecta Vagas <span class="text-warning">DF</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu" aria-controls="navMenu" aria-expanded="false" aria-label="Alternar navegação">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'home' ? 'active' : '' ?>" href="<?= e(BASE_URL) ?>?page=home">
                        <i class="bi bi-house-door"></i> Início
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'vagas' ? 'active' : '' ?>" href="<?= e(BASE_URL) ?>?page=vagas">
                        <i class="bi bi-briefcase"></i> Vagas
                    </a>
                </li>

                <?php if ($isAdminUser): ?>
                    <!-- Menu Exclusivo do Administrador -->
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage === 'candidatos' ? 'active' : '' ?>" href="<?= e(BASE_URL) ?>?page=candidatos">
                            <i class="bi bi-people"></i> Gestão de Candidatos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage === 'dashboard' ? 'active' : '' ?>" href="<?= e(BASE_URL) ?>?page=dashboard">
                            <i class="bi bi-bar-chart-line"></i> Dashboard
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($isCandidatoUser): ?>
                    <!-- Menu Exclusivo do Candidato -->
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage === 'perfil' ? 'active' : '' ?>" href="<?= e(BASE_URL) ?>?page=perfil">
                            <i class="bi bi-send-check"></i> Minhas Candidaturas
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

            <!-- Área de Login / Usuário -->
            <div class="d-flex align-items-center gap-2 mt-2 mt-lg-0">
                <?php if ($usuarioLogado): ?>
                    <div class="dropdown">
                        <button class="btn btn-outline-light dropdown-toggle d-flex align-items-center gap-2 py-1 px-3" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle fs-5"></i>
                            <span><?= e(truncateText($usuarioLogado['nome'], 20)) ?></span>
                            <span class="badge <?= $isAdminUser ? 'bg-danger' : 'bg-warning text-dark' ?> ms-1">
                                <?= $isAdminUser ? 'Admin' : 'Candidato' ?>
                            </span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow">
                            <li>
                                <div class="dropdown-header small text-muted">
                                    Conectado como<br><strong><?= e($usuarioLogado['email']) ?></strong>
                                </div>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item" href="<?= e(BASE_URL) ?>?page=perfil">
                                    <i class="bi bi-person-badge me-2 text-primary"></i> Meu Perfil
                                </a>
                            </li>
                            <?php if ($isCandidatoUser): ?>
                                <li>
                                    <a class="dropdown-item" href="<?= e(BASE_URL) ?>?page=perfil">
                                        <i class="bi bi-send-check me-2 text-success"></i> Minhas Candidaturas
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if ($isAdminUser): ?>
                                <li>
                                    <a class="dropdown-item" href="<?= e(BASE_URL) ?>?page=dashboard">
                                        <i class="bi bi-speedometer2 me-2 text-info"></i> Painel Dashboard
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="<?= e(BASE_URL) ?>?page=candidatos">
                                        <i class="bi bi-people me-2 text-primary"></i> Gestão de Candidatos
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item text-danger" href="<?= e(BASE_URL) ?>?page=logout">
                                    <i class="bi bi-box-arrow-right me-2"></i> Sair da Conta
                                </a>
                            </li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="<?= e(BASE_URL) ?>?page=login" class="btn btn-outline-light btn-sm">
                        <i class="bi bi-box-arrow-in-right"></i> Entrar
                    </a>
                    <a href="<?= e(BASE_URL) ?>?page=cadastro" class="btn btn-warning btn-sm fw-semibold">
                        <i class="bi bi-person-plus"></i> Cadastrar-se
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<main class="container my-4">
    <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show shadow-sm" role="alert">
            <i class="bi bi-info-circle me-1"></i> <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
        </div>
    <?php endif; ?>
