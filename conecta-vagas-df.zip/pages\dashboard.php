<?php
requireAdmin();

$stats = getDashboardStats();
$statusOpcoes = getStatusCandidaturaOpcoes();
?>

<h1 class="h3 fw-bold mb-4"><i class="bi bi-bar-chart-line"></i> Dashboard Estatístico</h1>

<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card cvdf-stat-card h-100 text-center shadow-sm border-0">
            <div class="card-body">
                <i class="bi bi-briefcase-fill fs-2 text-primary"></i>
                <h3 class="fw-bold mt-2 mb-0"><?= (int) $stats['total_vagas'] ?></h3>
                <p class="text-muted small mb-0">Total de Vagas</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card cvdf-stat-card h-100 text-center shadow-sm border-0">
            <div class="card-body">
                <i class="bi bi-check-circle-fill fs-2 text-success"></i>
                <h3 class="fw-bold mt-2 mb-0"><?= (int) $stats['vagas_ativas'] ?></h3>
                <p class="text-muted small mb-0">Vagas Ativas</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card cvdf-stat-card h-100 text-center shadow-sm border-0">
            <div class="card-body">
                <i class="bi bi-people-fill fs-2 text-info"></i>
                <h3 class="fw-bold mt-2 mb-0"><?= (int) $stats['total_candidatos'] ?></h3>
                <p class="text-muted small mb-0">Total de Candidatos</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card cvdf-stat-card h-100 text-center shadow-sm border-0">
            <div class="card-body">
                <i class="bi bi-map-fill fs-2 text-warning"></i>
                <h3 class="fw-bold mt-2 mb-0"><?= (int) $stats['total_ras'] ?></h3>
                <p class="text-muted small mb-0">Regiões Atendidas</p>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Candidatos por status -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h5 class="fw-bold mb-3"><i class="bi bi-pie-chart"></i> Candidatos por Status</h5>
                <?php $totalCand = array_sum($stats['por_status']) ?: 1; ?>
                <?php foreach ($stats['por_status'] as $key => $total): ?>
                    <?php $perc = round(($total / $totalCand) * 100); ?>
                    <div class="mb-2">
                        <div class="d-flex justify-content-between small mb-1">
                            <span><?= e($statusOpcoes[$key]['label'] ?? $key) ?></span>
                            <span><?= (int) $total ?> (<?= $perc ?>%)</span>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-<?= e($statusOpcoes[$key]['class'] ?? 'secondary') ?>" style="width: <?= $perc ?>%"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Vagas por tipo de contrato -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h5 class="fw-bold mb-3"><i class="bi bi-file-earmark-text"></i> Vagas por Tipo de Contrato</h5>
                <?php $totalVagasTipo = array_sum(array_column($stats['vagas_por_tipo'], 'total')) ?: 1; ?>
                <?php foreach ($stats['vagas_por_tipo'] as $row): ?>
                    <?php $perc = round(($row['total'] / $totalVagasTipo) * 100); ?>
                    <div class="mb-2">
                        <div class="d-flex justify-content-between small mb-1">
                            <span><?= e($row['tipo_contrato']) ?></span>
                            <span><?= (int) $row['total'] ?> (<?= $perc ?>%)</span>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-primary" style="width: <?= $perc ?>%"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Vagas por RA -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h5 class="fw-bold mb-3"><i class="bi bi-geo-alt"></i> Vagas por Região Administrativa</h5>
                <div class="table-responsive" style="max-height: 320px; overflow-y: auto;">
                    <table class="table table-sm mb-0">
                        <thead>
                            <tr><th>RA</th><th class="text-end">Vagas</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($stats['vagas_por_ra'] as $row): ?>
                                <tr>
                                    <td><?= e($row['ra']) ?></td>
                                    <td class="text-end"><span class="badge bg-primary"><?= (int) $row['total'] ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Top vagas com mais candidaturas -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h5 class="fw-bold mb-3"><i class="bi bi-trophy"></i> Vagas com Mais Candidaturas</h5>
                <?php if (empty($stats['top_vagas'])): ?>
                    <p class="text-muted small">Nenhuma candidatura registrada ainda.</p>
                <?php else: ?>
                    <table class="table table-sm mb-0">
                        <thead>
                            <tr><th>Vaga</th><th>Empresa</th><th class="text-end">Candidatos</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($stats['top_vagas'] as $row): ?>
                                <tr>
                                    <td><a href="<?= e(BASE_URL) ?>?page=vaga&id=<?= (int) $row['id'] ?>"><?= e($row['titulo']) ?></a></td>
                                    <td class="text-muted small"><?= e($row['empresa']) ?></td>
                                    <td class="text-end"><span class="badge bg-success"><?= (int) $row['total_candidatos'] ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
