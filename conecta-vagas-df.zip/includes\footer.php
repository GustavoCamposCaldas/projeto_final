</main>

<footer class="cvdf-footer text-light py-4 mt-auto">
    <div class="container">
        <div class="row gy-3">
            <div class="col-md-4">
                <h5 class="fw-bold"><i class="bi bi-geo-alt-fill"></i> Conecta Vagas DF</h5>
                <p class="small mb-0">Conectando talentos do Distrito Federal às oportunidades das 33 Regiões Administrativas.</p>
            </div>
            <div class="col-md-4">
                <h6 class="fw-bold">Links Rápidos</h6>
                <ul class="list-unstyled small">
                    <li><a href="<?= e(BASE_URL) ?>?page=vagas" class="footer-link">Ver Vagas</a></li>
                    <li><a href="<?= e(BASE_URL) ?>?page=candidatos" class="footer-link">Gestão de Candidatos</a></li>
                    <li><a href="<?= e(BASE_URL) ?>?page=dashboard" class="footer-link">Dashboard</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h6 class="fw-bold">Sobre</h6>
                <p class="small mb-0">Versão <?= e(SITE_VERSION) ?> &middot; Projeto acadêmico desenvolvido em PHP + MySQL/SQLite + Bootstrap 5.</p>
            </div>
        </div>
        <hr class="border-secondary">
        <p class="small text-center mb-0">&copy; <?= date('Y') ?> Conecta Vagas DF. Todos os direitos reservados.</p>
    </div>
</footer>

<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Script customizado -->
<script src="<?= e(BASE_URL) ?>assets/js/script.js"></script>
</body>
</html>
