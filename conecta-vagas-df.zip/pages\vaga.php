<?php
$id = sanitizeInt($_GET['id'] ?? 0);
$vaga = $id ? getVagaById($id) : null;

if (!$vaga) {
    setFlashMessage('warning', 'Vaga não encontrada.');
    redirect(BASE_URL . '?page=vagas');
}

// ------------------------------------------------------------
// Processamento da candidatura (POST)
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'candidatar') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Token de segurança inválido. Tente novamente.');
        redirect(BASE_URL . '?page=vaga&id=' . $id);
    }

    $nome     = sanitizeInput($_POST['nome'] ?? '');
    $email    = sanitizeInput($_POST['email'] ?? '');
    $telefone = sanitizeInput($_POST['telefone'] ?? '');
    $ra       = sanitizeInput($_POST['ra'] ?? '');
    $mensagem = sanitizeInput($_POST['mensagem'] ?? '');

    $erros = [];
    if (mb_strlen($nome) < 3) $erros[] = 'Informe seu nome completo.';
    if (!validateEmail($email)) $erros[] = 'Informe um e-mail válido.';
    if (!validatePhone($telefone)) $erros[] = 'Informe um telefone válido com DDD.';
    if (!in_array($ra, getRegioesAdministrativas(), true)) $erros[] = 'Selecione sua Região Administrativa.';

    if (empty($erros)) {
        createCandidatura([
            'vaga_id' => $vaga['id'], 'nome' => $nome, 'email' => $email,
            'telefone' => $telefone, 'ra' => $ra, 'mensagem' => $mensagem,
        ]);
        setFlashMessage('success', 'Candidatura enviada com sucesso! Boa sorte, ' . $nome . '!');
        redirect(BASE_URL . '?page=vaga&id=' . $id);
    } else {
        setFlashMessage('danger', implode(' ', $erros));
        redirect(BASE_URL . '?page=vaga&id=' . $id);
    }
}

$statusVaga = getStatusVagaOpcoes();
$vagaEncerrada = $vaga['status'] !== 'ativa';
$usuarioLogado = getUsuarioLogado();
$candidaturaExistente = null;

if ($usuarioLogado) {
    $candidaturaExistente = usuarioJaCandidatou($vaga['id'], $usuarioLogado['email']);
}
?>

<nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb small">
        <li class="breadcrumb-item"><a href="<?= e(BASE_URL) ?>?page=vagas">Vagas</a></li>
        <li class="breadcrumb-item active"><?= e($vaga['titulo']) ?></li>
    </ol>
</nav>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <span class="badge bg-<?= e($statusVaga[$vaga['status']]['class'] ?? 'secondary') ?> mb-2">
                    <?= e($statusVaga[$vaga['status']]['label'] ?? $vaga['status']) ?>
                </span>
                <h1 class="h3 fw-bold"><?= e($vaga['titulo']) ?></h1>
                <p class="text-muted mb-3"><i class="bi bi-building"></i> <?= e($vaga['empresa']) ?></p>

                <div class="row g-2 mb-4">
                    <div class="col-6 col-md-3">
                        <div class="cvdf-info-box text-center p-2">
                            <i class="bi bi-geo-alt text-primary"></i>
                            <p class="small mb-0 fw-semibold"><?= e($vaga['ra']) ?></p>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="cvdf-info-box text-center p-2">
                            <i class="bi bi-file-earmark-text text-primary"></i>
                            <p class="small mb-0 fw-semibold"><?= e($vaga['tipo_contrato']) ?></p>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="cvdf-info-box text-center p-2">
                            <i class="bi bi-cash-coin text-primary"></i>
                            <p class="small mb-0 fw-semibold"><?= formatSalario($vaga['salario']) ?></p>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="cvdf-info-box text-center p-2">
                            <i class="bi bi-person-vcard text-primary"></i>
                            <p class="small mb-0 fw-semibold"><?= (int) $vaga['vagas_disponiveis'] ?> vaga(s)</p>
                        </div>
                    </div>
                </div>

                <h5 class="fw-bold">Descrição da Vaga</h5>
                <p style="white-space: pre-line;"><?= e($vaga['descricao']) ?></p>

                <?php if (!empty($vaga['requisitos'])): ?>
                    <h5 class="fw-bold">Requisitos</h5>
                    <p style="white-space: pre-line;"><?= e($vaga['requisitos']) ?></p>
                <?php endif; ?>

                <p class="text-muted small mb-0"><i class="bi bi-clock-history"></i> Publicada em <?= formatDate($vaga['data_publicacao']) ?></p>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card border-0 shadow-sm cvdf-form-candidatura">
            <div class="card-body">
                <h5 class="fw-bold mb-3"><i class="bi bi-send"></i> Candidatar-se a esta vaga</h5>

                <?php if ($vagaEncerrada): ?>
                    <div class="alert alert-warning small mb-0">
                        <i class="bi bi-exclamation-triangle"></i> Esta vaga não está mais recebendo candidaturas no momento.
                    </div>
                <?php elseif ($candidaturaExistente): ?>
                    <?php
                    $statusOpcoes = getStatusCandidaturaOpcoes();
                    $stKey = $candidaturaExistente['status'] ?? 'pendente';
                    $stInfo = $statusOpcoes[$stKey] ?? ['label' => ucfirst($stKey), 'class' => 'secondary'];
                    ?>
                    <div class="alert alert-success border-0 bg-success bg-opacity-10 mb-3">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <i class="bi bi-check-circle-fill text-success fs-4"></i>
                            <strong class="text-success">Você já se candidatou a esta vaga!</strong>
                        </div>
                        <p class="small mb-2">Sua candidatura foi registrada em <strong><?= formatDate($candidaturaExistente['data_candidatura']) ?></strong>.</p>
                        <div class="mb-3">
                            <span class="badge bg-<?= e($stInfo['class']) ?> px-3 py-2 fs-6">
                                Status: <?= e($stInfo['label']) ?>
                            </span>
                        </div>
                        <a href="<?= e(BASE_URL) ?>?page=perfil" class="btn btn-primary btn-sm w-100">
                            <i class="bi bi-person-lines-fill"></i> Ver Meu Perfil & Candidaturas
                        </a>
                    </div>
                <?php else: ?>
                    <?php if (!$usuarioLogado): ?>
                        <div class="alert alert-info py-2 px-3 small mb-3">
                            <i class="bi bi-info-circle"></i> Já tem uma conta? <a href="<?= e(BASE_URL) ?>?page=login" class="fw-semibold">Faça Login</a> para preenchimento automático.
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?= e(BASE_URL) ?>?page=vaga&id=<?= (int) $vaga['id'] ?>" class="needs-validation" novalidate>
                        <?= csrfField() ?>
                        <input type="hidden" name="acao" value="candidatar">

                        <div class="mb-3">
                            <label class="form-label">Nome Completo *</label>
                            <input type="text" name="nome" class="form-control" value="<?= e($usuarioLogado['nome'] ?? '') ?>" required minlength="3">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">E-mail *</label>
                            <input type="email" name="email" class="form-control" value="<?= e($usuarioLogado['email'] ?? '') ?>" <?= $usuarioLogado ? 'readonly' : '' ?> required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Telefone *</label>
                            <input type="text" name="telefone" class="form-control" placeholder="(61) 90000-0000" value="<?= e($usuarioLogado['telefone'] ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Sua Região Administrativa *</label>
                            <select name="ra" class="form-select" required>
                                <option value="">Selecione...</option>
                                <?php foreach (getRegioesAdministrativas() as $ra): ?>
                                    <option value="<?= e($ra) ?>" <?= ($usuarioLogado['ra'] ?? '') === $ra ? 'selected' : '' ?>><?= e($ra) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Mensagem (opcional)</label>
                            <textarea name="mensagem" class="form-control" rows="3" placeholder="Conte um pouco sobre sua experiência..."><?= e($usuarioLogado['bio'] ?? '') ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-send-fill"></i> Enviar Candidatura
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
