<?php
$isAdminUser = isAdmin();

// ------------------------------------------------------------
// Processamento do formulário de cadastro de vaga (POST - Admin)
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'criar_vaga') {
    if (!$isAdminUser) {
        setFlashMessage('danger', 'Apenas administradores podem cadastrar novas vagas.');
        redirect(BASE_URL . '?page=vagas');
    }

    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Token de segurança inválido. Tente novamente.');
        redirect(BASE_URL . '?page=vagas');
    }

    $titulo    = sanitizeInput($_POST['titulo'] ?? '');
    $empresa   = sanitizeInput($_POST['empresa'] ?? '');
    $ra        = sanitizeInput($_POST['ra'] ?? '');
    $tipo      = sanitizeInput($_POST['tipo_contrato'] ?? '');
    $salario   = sanitizeFloat($_POST['salario'] ?? 0);
    $descricao = sanitizeInput($_POST['descricao'] ?? '');
    $requisitos = sanitizeInput($_POST['requisitos'] ?? '');
    $qtd       = sanitizeInt($_POST['vagas_disponiveis'] ?? 1);

    $erros = [];
    if ($titulo === '' || mb_strlen($titulo) < 3) $erros[] = 'Informe um título válido.';
    if ($empresa === '') $erros[] = 'Informe o nome da empresa.';
    if (!in_array($ra, getRegioesAdministrativas(), true)) $erros[] = 'Selecione uma Região Administrativa válida.';
    if (!in_array($tipo, getTiposContrato(), true)) $erros[] = 'Selecione um tipo de contrato válido.';
    if ($descricao === '' || mb_strlen($descricao) < 10) $erros[] = 'Descreva a vaga com mais detalhes.';
    if ($qtd < 1) $qtd = 1;

    if (empty($erros)) {
        createVaga([
            'titulo' => $titulo, 'empresa' => $empresa, 'ra' => $ra, 'tipo_contrato' => $tipo,
            'salario' => $salario, 'descricao' => $descricao, 'requisitos' => $requisitos,
            'vagas_disponiveis' => $qtd, 'status' => 'ativa',
        ]);
        setFlashMessage('success', 'Vaga cadastrada com sucesso!');
        redirect(BASE_URL . '?page=vagas');
    } else {
        setFlashMessage('danger', implode(' ', $erros));
        redirect(BASE_URL . '?page=vagas');
    }
}

// ------------------------------------------------------------
// Alterar status ou excluir vaga (ações rápidas - Admin)
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'status_vaga') {
    if ($isAdminUser && validateCSRFToken($_POST['csrf_token'] ?? '')) {
        updateVagaStatus((int) $_POST['vaga_id'], sanitizeInput($_POST['status']));
        setFlashMessage('success', 'Status da vaga atualizado.');
    }
    redirect(BASE_URL . '?page=vagas');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'excluir_vaga') {
    if ($isAdminUser && validateCSRFToken($_POST['csrf_token'] ?? '')) {
        deleteVaga((int) $_POST['vaga_id']);
        setFlashMessage('success', 'Vaga excluída com sucesso.');
    }
    redirect(BASE_URL . '?page=vagas');
}

// ------------------------------------------------------------
// Filtros de listagem (GET)
// ------------------------------------------------------------
$filtroRa     = sanitizeInput($_GET['ra'] ?? '');
$filtroTipo   = sanitizeInput($_GET['tipo_contrato'] ?? '');
$filtroBusca  = sanitizeInput($_GET['busca'] ?? '');

$vagas = getAllVagas([
    'ra' => $filtroRa,
    'tipo_contrato' => $filtroTipo,
    'busca' => $filtroBusca,
]);

$statusVaga = getStatusVagaOpcoes();
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
    <div>
        <h1 class="h3 fw-bold mb-0"><i class="bi bi-briefcase"></i> Vagas Disponíveis</h1>
        <p class="text-muted small mb-0">Confira as vagas de emprego abertas no DF</p>
    </div>
    <?php if ($isAdminUser): ?>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCadastroVaga">
            <i class="bi bi-plus-circle"></i> Cadastrar Nova Vaga
        </button>
    <?php endif; ?>
</div>

<!-- Filtros -->
<form method="GET" action="<?= e(BASE_URL) ?>" class="card border-0 shadow-sm p-3 mb-4">
    <input type="hidden" name="page" value="vagas">
    <div class="row g-2">
        <div class="col-md-4">
            <label class="form-label small fw-semibold">Região Administrativa</label>
            <select name="ra" class="form-select">
                <option value="">Todas as RAs</option>
                <?php foreach (getRegioesAdministrativas() as $ra): ?>
                    <option value="<?= e($ra) ?>" <?= $filtroRa === $ra ? 'selected' : '' ?>><?= e($ra) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label small fw-semibold">Tipo de Contrato</label>
            <select name="tipo_contrato" class="form-select">
                <option value="">Todos</option>
                <?php foreach (getTiposContrato() as $tipo): ?>
                    <option value="<?= e($tipo) ?>" <?= $filtroTipo === $tipo ? 'selected' : '' ?>><?= e($tipo) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label small fw-semibold">Buscar</label>
            <input type="text" name="busca" class="form-control" placeholder="Título ou empresa..." value="<?= e($filtroBusca) ?>">
        </div>
        <div class="col-md-1 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100"><i class="bi bi-funnel"></i></button>
        </div>
    </div>
</form>

<p class="text-muted small mb-3"><?= count($vagas) ?> vaga(s) encontrada(s)</p>

<?php if (empty($vagas)): ?>
    <div class="alert alert-secondary">Nenhuma vaga encontrada com os filtros selecionados.</div>
<?php else: ?>
    <div class="row g-4">
        <?php foreach ($vagas as $vaga): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 shadow-sm border-0 cvdf-vaga-card">
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="badge bg-<?= e($statusVaga[$vaga['status']]['class'] ?? 'secondary') ?>">
                                <?= e($statusVaga[$vaga['status']]['label'] ?? $vaga['status']) ?>
                            </span>
                            <span class="badge bg-light text-dark border"><?= (int) $vaga['total_candidatos'] ?> candidato(s)</span>
                        </div>
                        <h5 class="card-title fw-bold"><?= e($vaga['titulo']) ?></h5>
                        <p class="card-subtitle text-muted mb-2"><i class="bi bi-building"></i> <?= e($vaga['empresa']) ?></p>
                        <p class="small mb-1"><i class="bi bi-geo-alt"></i> <?= e($vaga['ra']) ?></p>
                        <p class="small mb-3"><i class="bi bi-file-text"></i> <?= e($vaga['tipo_contrato']) ?> &middot; <?= formatSalario($vaga['salario']) ?> &middot; <?= (int) $vaga['vagas_disponiveis'] ?> vaga(s)</p>
                        <p class="card-text small text-muted flex-grow-1"><?= e(truncateText($vaga['descricao'], 100)) ?></p>

                        <div class="d-flex gap-2 mt-2">
                            <a href="<?= e(BASE_URL) ?>?page=vaga&id=<?= (int) $vaga['id'] ?>" class="btn btn-outline-primary btn-sm flex-grow-1">
                                <i class="bi bi-eye"></i> Detalhes
                            </a>
                            <?php if ($isAdminUser): ?>
                                <button type="button" class="btn btn-outline-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modalExcluir<?= (int) $vaga['id'] ?>" title="Excluir Vaga (Admin)">
                                    <i class="bi bi-trash"></i>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($isAdminUser): ?>
                <!-- Modal Confirmação de Exclusão (Admin) -->
                <div class="modal fade" id="modalExcluir<?= (int) $vaga['id'] ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" action="<?= e(BASE_URL) ?>?page=vagas">
                                <?= csrfField() ?>
                                <input type="hidden" name="acao" value="excluir_vaga">
                                <input type="hidden" name="vaga_id" value="<?= (int) $vaga['id'] ?>">
                                <div class="modal-header">
                                    <h5 class="modal-title">Excluir Vaga</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    Tem certeza que deseja excluir a vaga <strong><?= e($vaga['titulo']) ?></strong>? Essa ação não pode ser desfeita.
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-danger">Excluir</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Modal Cadastro de Vaga -->
<div class="modal fade" id="modalCadastroVaga" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="<?= e(BASE_URL) ?>?page=vagas" class="needs-validation" novalidate>
                <?= csrfField() ?>
                <input type="hidden" name="acao" value="criar_vaga">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Cadastrar Nova Vaga</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Título da Vaga *</label>
                            <input type="text" name="titulo" class="form-control" required minlength="3" maxlength="150">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Empresa *</label>
                            <input type="text" name="empresa" class="form-control" required maxlength="150">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Região Administrativa *</label>
                            <select name="ra" class="form-select" required>
                                <option value="">Selecione...</option>
                                <?php foreach (getRegioesAdministrativas() as $ra): ?>
                                    <option value="<?= e($ra) ?>"><?= e($ra) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Tipo de Contrato *</label>
                            <select name="tipo_contrato" class="form-select" required>
                                <?php foreach (getTiposContrato() as $tipo): ?>
                                    <option value="<?= e($tipo) ?>"><?= e($tipo) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Salário (R$)</label>
                            <input type="number" step="0.01" min="0" name="salario" class="form-control" value="0">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Vagas Disponíveis</label>
                            <input type="number" min="1" name="vagas_disponiveis" class="form-control" value="1">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Descrição *</label>
                            <textarea name="descricao" class="form-control" rows="3" required minlength="10"></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Requisitos</label>
                            <textarea name="requisitos" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-circle"></i> Cadastrar Vaga</button>
                </div>
            </form>
        </div>
    </div>
</div>
