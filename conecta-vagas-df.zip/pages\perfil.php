﻿<?php
requireLogin();
$usuario = getUsuarioLogado();

// Se for admin acessando perfil, dar opção de ir ao dashboard
$isAdminUser = isAdmin();

// Processar atualização de perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'atualizar_perfil') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Token de segurança expirado.');
        redirect(BASE_URL . '?page=perfil');
    }

    $nome     = sanitizeInput($_POST['nome'] ?? '');
    $telefone = sanitizeInput($_POST['telefone'] ?? '');
    $ra       = sanitizeInput($_POST['ra'] ?? '');
    $bio      = sanitizeInput($_POST['bio'] ?? '');

    $erros = [];
    if (mb_strlen($nome) < 3) $erros[] = 'Informe um nome válido.';
    if (!validatePhone($telefone)) $erros[] = 'Informe um telefone válido.';
    if (!in_array($ra, getRegioesAdministrativas(), true)) $erros[] = 'Selecione uma Região Administrativa válida.';

    if (empty($erros)) {
        atualizarPerfilUsuario($usuario['id'], [
            'nome'     => $nome,
            'telefone' => $telefone,
            'ra'       => $ra,
            'bio'      => $bio,
        ]);
        setFlashMessage('success', 'Perfil atualizado com sucesso!');
        redirect(BASE_URL . '?page=perfil');
    } else {
        setFlashMessage('danger', implode('<br>', $erros));
        redirect(BASE_URL . '?page=perfil');
    }
}

// Processar alteração de senha
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'alterar_senha') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Token de segurança expirado.');
        redirect(BASE_URL . '?page=perfil');
    }

    $senhaAtual = $_POST['senha_atual'] ?? '';
    $novaSenha  = $_POST['nova_senha'] ?? '';
    $confSenha  = $_POST['confirmar_senha'] ?? '';

    // Validar senha atual
    $stmt = $pdo->prepare("SELECT senha FROM usuarios WHERE id = :id");
    $stmt->execute([':id' => $usuario['id']]);
    $hashAtual = $stmt->fetchColumn();

    if (!password_verify($senhaAtual, $hashAtual)) {
        setFlashMessage('danger', 'Senha atual incorreta.');
    } elseif (mb_strlen($novaSenha) < 6) {
        setFlashMessage('danger', 'A nova senha deve ter pelo menos 6 caracteres.');
    } elseif ($novaSenha !== $confSenha) {
        setFlashMessage('danger', 'A confirmação da nova senha não confere.');
    } else {
        atualizarSenhaUsuario($usuario['id'], $novaSenha);
        setFlashMessage('success', 'Senha alterada com sucesso!');
    }
    redirect(BASE_URL . '?page=perfil');
}

// Processar cancelamento de candidatura
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'cancelar_candidatura') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Token de segurança expirado.');
        redirect(BASE_URL . '?page=perfil');
    }

    $candId = sanitizeInt($_POST['candidatura_id'] ?? 0);
    if (cancelarCandidatura($candId, $usuario['email'])) {
        setFlashMessage('success', 'Candidatura cancelada com sucesso.');
    } else {
        setFlashMessage('danger', 'Não foi possível cancelar esta candidatura.');
    }
    redirect(BASE_URL . '?page=perfil');
}

// Buscar candidaturas deste usuário
$minhasCandidaturas = getCandidaturasPorEmail($usuario['email']);
$statusOpcoes = getStatusCandidaturaOpcoes();
?>

<!-- Cabeçalho do Perfil -->
<div class="card border-0 shadow-sm mb-4 bg-primary text-white p-4 rounded-3">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
        <div class="d-flex align-items-center gap-3">
            <div class="bg-white text-primary rounded-circle d-flex align-items-center justify-content-center fw-bold fs-2" style="width: 64px; height: 64px;">
                <?= strtoupper(mb_substr($usuario['nome'], 0, 1)) ?>
            </div>
            <div>
                <h1 class="h3 fw-bold mb-1"><?= e($usuario['nome']) ?></h1>
                <div class="d-flex flex-wrap align-items-center gap-2 small">
                    <span><i class="bi bi-envelope"></i> <?= e($usuario['email']) ?></span>
                    <span>&middot;</span>
                    <span><i class="bi bi-geo-alt"></i> <?= e($usuario['ra'] ?: 'Distrito Federal') ?></span>
                    <span>&middot;</span>
                    <span class="badge <?= $isAdminUser ? 'bg-danger' : 'bg-warning text-dark' ?>">
                        <?= $isAdminUser ? 'Administrador' : 'Candidato(a)' ?>
                    </span>
                </div>
            </div>
        </div>
        <div class="d-flex gap-2">
            <?php if ($isAdminUser): ?>
                <a href="<?= e(BASE_URL) ?>?page=dashboard" class="btn btn-light btn-sm fw-semibold">
                    <i class="bi bi-speedometer2"></i> Ir para o Painel Admin
                </a>
            <?php endif; ?>
            <a href="<?= e(BASE_URL) ?>?page=vagas" class="btn btn-warning btn-sm fw-semibold">
                <i class="bi bi-search"></i> Buscar Vagas
            </a>
            <a href="<?= e(BASE_URL) ?>?page=logout" class="btn btn-outline-light btn-sm">
                <i class="bi bi-box-arrow-right"></i> Sair
            </a>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Coluna da Esquerda: Dados do Perfil -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3 border-0">
                <h5 class="fw-bold mb-0"><i class="bi bi-person-badge text-primary"></i> Meus Dados Pessoais</h5>
            </div>
            <div class="card-body pt-0">
                <form method="POST" action="<?= e(BASE_URL) ?>?page=perfil" class="needs-validation" novalidate>
                    <?= csrfField() ?>
                    <input type="hidden" name="acao" value="atualizar_perfil">

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Nome Completo</label>
                        <input type="text" name="nome" class="form-control" value="<?= e($usuario['nome']) ?>" required minlength="3">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">E-mail</label>
                        <input type="email" class="form-control bg-light" value="<?= e($usuario['email']) ?>" readonly disabled>
                        <div class="form-text small">O e-mail é a sua chave de acesso e identificador de candidaturas.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Telefone / WhatsApp</label>
                        <input type="text" name="telefone" class="form-control" value="<?= e($usuario['telefone']) ?>" placeholder="(61) 90000-0000" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Região Administrativa (RA)</label>
                        <select name="ra" class="form-select" required>
                            <option value="">Selecione...</option>
                            <?php foreach (getRegioesAdministrativas() as $raItem): ?>
                                <option value="<?= e($raItem) ?>" <?= $usuario['ra'] === $raItem ? 'selected' : '' ?>><?= e($raItem) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Mini-currículo / Apresentação</label>
                        <textarea name="bio" class="form-control" rows="4" placeholder="Descreva sua experiência, cursos e principais competências..."><?= e($usuario['bio']) ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 fw-semibold">
                        <i class="bi bi-save"></i> Salvar Alterações
                    </button>
                </form>

                <hr class="my-3">

                <!-- Botão alterar senha -->
                <button type="button" class="btn btn-outline-secondary btn-sm w-100" data-bs-toggle="modal" data-bs-target="#modalAlterarSenha">
                    <i class="bi bi-shield-lock"></i> Alterar Minha Senha
                </button>
            </div>
        </div>
    </div>

    <!-- Coluna da Direita: Minhas Candidaturas e Status -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3 border-0 d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="fw-bold mb-0"><i class="bi bi-send-check-fill text-success"></i> Minhas Candidaturas</h5>
                    <p class="text-muted small mb-0">Acompanhe o andamento dos processos seletivos em tempo real</p>
                </div>
                <span class="badge bg-primary fs-6"><?= count($minhasCandidaturas) ?> vaga(s)</span>
            </div>
            <div class="card-body pt-0">
                <?php if (empty($minhasCandidaturas)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-briefcase text-muted display-4"></i>
                        <h5 class="fw-bold mt-3">Você ainda não se candidatou a nenhuma vaga</h5>
                        <p class="text-muted small">Explore as vagas disponíveis em todas as Regiões Administrativas do DF e candidate-se com 1 clique.</p>
                        <a href="<?= e(BASE_URL) ?>?page=vagas" class="btn btn-primary">
                            <i class="bi bi-search"></i> Ver Vagas Disponíveis
                        </a>
                    </div>
                <?php else: ?>
                    <div class="d-flex flex-column gap-3">
                        <?php foreach ($minhasCandidaturas as $cand): ?>
                            <?php
                            $statusKey = $cand['status'] ?? 'pendente';
                            $statusInfo = $statusOpcoes[$statusKey] ?? ['label' => ucfirst($statusKey), 'class' => 'secondary'];
                            ?>
                            <div class="card border shadow-none rounded-3 p-3">
                                <div class="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-2">
                                    <div>
                                        <h5 class="fw-bold mb-1">
                                            <a href="<?= e(BASE_URL) ?>?page=vaga&id=<?= (int) $cand['vaga_id'] ?>" class="text-decoration-none text-dark">
                                                <?= e($cand['vaga_titulo']) ?>
                                            </a>
                                        </h5>
                                        <div class="text-muted small d-flex flex-wrap align-items-center gap-2">
                                            <span><i class="bi bi-building"></i> <?= e($cand['vaga_empresa']) ?></span>
                                            <span>&middot;</span>
                                            <span><i class="bi bi-geo-alt"></i> <?= e($cand['vaga_ra']) ?></span>
                                            <span>&middot;</span>
                                            <span><i class="bi bi-file-text"></i> <?= e($cand['vaga_tipo']) ?></span>
                                            <span>&middot;</span>
                                            <span><i class="bi bi-cash"></i> <?= formatSalario($cand['vaga_salario']) ?></span>
                                        </div>
                                    </div>
                                    <div class="text-end">
                                        <span class="badge bg-<?= e($statusInfo['class']) ?> px-3 py-2 fs-6">
                                            <i class="bi bi-arrow-repeat me-1"></i> Status: <?= e($statusInfo['label']) ?>
                                        </span>
                                    </div>
                                </div>

                                <!-- Detalhes do Status Explicado -->
                                <div class="alert alert-<?= e($statusInfo['class']) ?> py-2 px-3 mb-2 small bg-opacity-10 border-0">
                                    <?php if ($statusKey === 'pendente'): ?>
                                        <i class="bi bi-clock-history"></i> <strong>Aguardando avaliação:</strong> Sua candidatura foi enviada e está na fila para análise pela empresa.
                                    <?php elseif ($statusKey === 'em_analise'): ?>
                                        <i class="bi bi-file-earmark-person"></i> <strong>Em análise:</strong> O recrutador está avaliando seu currículo e perfil.
                                    <?php elseif ($statusKey === 'entrevista'): ?>
                                        <i class="bi bi-calendar2-check-fill"></i> <strong>Convocado(a) para entrevista!</strong> A empresa selecionou seu perfil para a próxima etapa. Fique atento(a) ao seu telefone e e-mail!
                                    <?php elseif ($statusKey === 'aprovado'): ?>
                                        <i class="bi bi-check-circle-fill"></i> <strong>Parabéns!</strong> Você foi aprovado(a) neste processo seletivo. A empresa entrará em contato com os próximos passos.
                                    <?php elseif ($statusKey === 'rejeitado'): ?>
                                        <i class="bi bi-x-circle-fill"></i> <strong>Processo finalizado:</strong> Agradecemos sua participação. Seu perfil não foi selecionado para esta oportunidade específica, mas continue se candidatando!
                                    <?php endif; ?>
                                </div>

                                <?php if (!empty($cand['mensagem'])): ?>
                                    <p class="small text-muted mb-2">
                                        <strong>Mensagem enviada:</strong> <em>"<?= e($cand['mensagem']) ?>"</em>
                                    </p>
                                <?php endif; ?>

                                <div class="d-flex justify-content-between align-items-center pt-2 border-top small text-muted">
                                    <span><i class="bi bi-calendar-event"></i> Candidatou-se em: <?= formatDate($cand['data_candidatura']) ?></span>
                                    <div class="d-flex gap-2">
                                        <a href="<?= e(BASE_URL) ?>?page=vaga&id=<?= (int) $cand['vaga_id'] ?>" class="btn btn-outline-primary btn-sm">
                                            <i class="bi bi-eye"></i> Ver Vaga
                                        </a>
                                        <button type="button" class="btn btn-outline-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modalCancelarCand<?= (int) $cand['id'] ?>">
                                            <i class="bi bi-x-lg"></i> Cancelar
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal Cancelar Candidatura -->
                            <div class="modal fade" id="modalCancelarCand<?= (int) $cand['id'] ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST" action="<?= e(BASE_URL) ?>?page=perfil">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="acao" value="cancelar_candidatura">
                                            <input type="hidden" name="candidatura_id" value="<?= (int) $cand['id'] ?>">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Cancelar Candidatura</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                Deseja realmente cancelar sua candidatura para a vaga <strong><?= e($cand['vaga_titulo']) ?></strong> na empresa <strong><?= e($cand['vaga_empresa']) ?></strong>?
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Voltar</button>
                                                <button type="submit" class="btn btn-danger">Sim, Cancelar Candidatura</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal Alterar Senha -->
<div class="modal fade" id="modalAlterarSenha" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?= e(BASE_URL) ?>?page=perfil" class="needs-validation" novalidate>
                <?= csrfField() ?>
                <input type="hidden" name="acao" value="alterar_senha">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-shield-lock"></i> Alterar Senha</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Senha Atual *</label>
                        <input type="password" name="senha_atual" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Nova Senha (mínimo 6 caracteres) *</label>
                        <input type="password" name="nova_senha" class="form-control" required minlength="6">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Confirmar Nova Senha *</label>
                        <input type="password" name="confirmar_senha" class="form-control" required minlength="6">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar Nova Senha</button>
                </div>
            </form>
        </div>
    </div>
</div>
